/**
 *	Exception not invertierbar
 * @author Mulham Alesali, Nawid Shadab, Mahmoud Abdalrahman
 *
 */

public class NichtInvertierbarException extends Exception {

	public NichtInvertierbarException(String string) {
		// TODO Auto-generated constructor stub
		super(string);
	}

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	
	
}
